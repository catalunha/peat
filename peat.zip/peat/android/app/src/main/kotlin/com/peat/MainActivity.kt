package com.peat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
